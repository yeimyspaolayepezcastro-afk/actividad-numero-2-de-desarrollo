package com.universidad.chatbot.config;

public class ChatDtos {

    public record ChatRequest(
            String pregunta,
            String dominio
    ) {
        public ChatRequest {
            if (pregunta == null || pregunta.isBlank()) {
                throw new IllegalArgumentException("El campo 'pregunta' no puede estar vacío.");
            }
            if (dominio == null || dominio.isBlank()) {
                dominio = "tecnología";
            }
        }
    }

    public record ChatResponse(
            String respuesta,
            String modelo,
            String dominio
    ) {}
}